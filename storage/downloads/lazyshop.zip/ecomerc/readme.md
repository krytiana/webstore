npm init -y


npm install stripe mongoose express dotenv
npm install -D typescript @types/express @types/node
npm install  bcrypt jsonwebtoken sib-api-v3-sdk

npm install -D typescript ts-node @types/node @types/express @types/bcrypt @types/jsonwebtoken @types/mongoose

npm install -D nodemon

npm install cors
npm install --save-dev @types/cors
npm install --save-dev ts-node typescript nodemon @types/node

npm install axios

npm install -g ngrok //to make localhost visible to the internet
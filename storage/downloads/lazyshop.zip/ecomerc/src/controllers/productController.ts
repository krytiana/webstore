//src/controllers/productController.ts

import { Request, Response } from "express";
import { Product } from "../models/Product"

// GET ALL PRODUCTS
export async function getProducts(req: Request, res: Response) {
  try {
    const products = await Product.find({});
    res.render("index", { products });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
}

// GET PRODUCT DETAIL
export async function getProductDetail(req: Request, res: Response) {
  const { id } = req.params;

  try {
    const product = await Product.findById(id);
    if (!product) return res.status(404).send("Product not found");

    // Recommended products: same category, limit 4
    const recommended = await Product.find({
      category: product.category,
      _id: { $ne: product._id },
    }).limit(4);

    res.render("productDetail", { product, recommended });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
}

// OPTIONAL: GET SINGLE PRODUCT JSON (API)
export async function getProduct(req: Request, res: Response) {
  const { id } = req.params;

  try {
    const product = await Product.findById(id);
    if (!product) return res.status(404).send("Product not found");
    res.json(product);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
}
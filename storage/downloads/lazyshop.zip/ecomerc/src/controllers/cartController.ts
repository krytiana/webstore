// src/controllers/cartController.ts
import { Request, Response } from "express";
import { Cart } from "../models/cart";

export const addToCart = async (req: any, res: Response) => {
  try {
    const userId = req.user.userId;
    const { productId, quantity, size, color } = req.body;

    let cart = await Cart.findOne({ userId });

    if (!cart) {
      cart = await Cart.create({
        userId,
        items: [{ productId, quantity, size, color }]
      });
    } else {
      const itemIndex = cart.items.findIndex(
        (item: any) =>
          item.productId.toString() === productId &&
          item.size === size &&
          item.color === color
      );

      if (itemIndex > -1) {
        cart.items[itemIndex].quantity += quantity;
      } else {
        cart.items.push({ productId, quantity, size, color });
      }

      await cart.save();
    }

    res.json({ success: true });

  } catch (error) {
    res.status(500).json({ success: false });
  }
};

export const getCart = async (req: any, res: Response) => {
  try {
    const userId = req.user.userId;

    const cart = await Cart.findOne({ userId }).populate("items.productId");

    res.json({ success: true, cart });

  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching cart" });
  }
};


export const removeFromCart = async (req: any, res: Response) => {
  try {
    const userId = req.user.userId;
    const { productId, size, color } = req.body;

    const cart = await Cart.findOne({ userId });

    if (!cart) return res.json({ success: false });

    cart.items = cart.items.filter(
      (item: any) =>
        !(
          item.productId.toString() === productId &&
          item.size === size &&
          item.color === color
        )
    ) as any;

    await cart.save();

    res.json({ success: true, cart });

  } catch (error) {
    res.status(500).json({ success: false });
  }
};

export const updateCart = async (req: any, res: Response) => {
  try {
    const userId = req.user.userId;
    const { productId, size = null, color = null, change } = req.body;

    const cart = await Cart.findOne({ userId });
    if (!cart) return res.status(404).json({ success: false });

    const itemIndex = cart.items.findIndex(
      (i: any) =>
        i.productId.toString() === productId &&
        (i.size || null) === size &&
        (i.color || null) === color
    );

    if (itemIndex === -1) return res.status(404).json({ success: false });

    if (change === -9999) {
      cart.items.splice(itemIndex, 1); // Remove item
    } else {
      cart.items[itemIndex].quantity += change;
      if (cart.items[itemIndex].quantity <= 0) {
        cart.items.splice(itemIndex, 1);
      }
    }

    await cart.save();
    const populatedCart = await cart.populate("items.productId");
    res.json({ success: true, cart: populatedCart });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false });
  }
};
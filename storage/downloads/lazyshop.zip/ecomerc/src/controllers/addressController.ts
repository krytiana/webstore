import { Request, Response } from "express";
import { AddressModel } from "../models/address";
import { RequestWithUser } from "../middlewares/authMiddleware";

// ➕ Add Address
export const addAddress = async (req: RequestWithUser, res: Response) => {
  try {
    const userId = req.user?.userId;

    const address = await AddressModel.create({
      ...req.body,
      userId: userId!
    });

    res.json({ message: "Address added", address });

  } catch (err) {
    res.status(500).json({ message: "Error adding address" });
  }
};

// 📄 Get All Addresses
export const getAddresses = async (req: RequestWithUser, res: Response) => {
  try {
    const userId = req.user?.userId;

    const addresses = await AddressModel.findByUser(userId!);

    res.json(addresses);

  } catch (err) {
    res.status(500).json({ message: "Error fetching addresses" });
  }
};

// ✏️ Update Address
export const updateAddress = async (req: RequestWithUser, res: Response) => {
  try {
    const userId = req.user?.userId;

    const id = Array.isArray(req.params.id)
      ? req.params.id[0]
      : req.params.id;

    await AddressModel.update(id, userId!, req.body);

    res.json({ message: "Updated" });

  } catch (err) {
    res.status(500).json({ message: "Error updating" });
  }
};

// ❌ Delete Address
export const deleteAddress = async (req: RequestWithUser, res: Response) => {
  try {
    const userId = req.user?.userId;

    const id = Array.isArray(req.params.id)
      ? req.params.id[0]
      : req.params.id;

    await AddressModel.delete(id, userId!);

    res.json({ message: "Deleted" });

  } catch (err) {
    res.status(500).json({ message: "Error deleting" });
  }
};

// ⭐ Set Default
export const setDefaultAddress = async (req: RequestWithUser, res: Response) => {
  try {
    const userId = req.user?.userId;

    const id = Array.isArray(req.params.id)
      ? req.params.id[0]
      : req.params.id;

    await AddressModel.setDefault(id, userId!);

    res.json({ message: "Default set" });

  } catch (err) {
    res.status(500).json({ message: "Error setting default" });
  }
};
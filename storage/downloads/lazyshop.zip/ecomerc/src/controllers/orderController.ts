import { Request, Response } from "express";
import Order from "../models/Order";

export const getUserOrders = async (req: any, res: Response) => {
  try {
    const orders = await Order.find({ userId: req.user._id })
      .populate("items.productId");

    res.json({ orders });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch orders" });
  }
};
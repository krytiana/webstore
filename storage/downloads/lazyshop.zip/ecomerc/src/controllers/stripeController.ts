// src/controllers/stripeController.ts
import { Request, Response } from "express";
import { stripe } from "../config/stripe";
import { Cart } from "../models/cart";
import Order from "../models/Order";
import mongoose from "mongoose";

// ----------------------------
// Cart-based checkout
// ----------------------------
export const createCartCheckoutSession = async (req: any, res: Response) => {
  try {
    const userId = req.user.userId;

    // Fetch user's cart and populate product details
    const cart = await Cart.findOne({ userId }).populate("items.productId");

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ success: false, message: "Cart is empty" });
    }

    // Type assertion: tell TS each item.productId is populated
    const cartItems = cart.items.map(item => item as any);

    // Map cart items to Stripe line items
    const line_items = cartItems.map(item => {
      const product = item.productId;
      return {
        price_data: {
          currency: "usd",
          product_data: {
            name: product.name,
            images: [product.images?.[0] || "https://via.placeholder.com/300"],
          },
          unit_amount: Math.round(product.price * 100),
        },
        quantity: item.quantity,
      };
    });

    // Create Stripe checkout session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items,
      mode: "payment",
      success_url: `${process.env.FRONTEND_URL}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/cancel.html`,
      metadata: {
        userId: userId.toString(),
      },
    });

    res.json({ url: session.url });

  } catch (err) {
    console.error("Stripe cart checkout error:", err);
    res.status(500).json({ success: false, message: "Stripe checkout failed" });
  }
};

// ----------------------------
// Stripe webhook for order creation
// ----------------------------
export const stripeWebhook = async (req: Request, res: Response) => {
  const sig = req.headers["stripe-signature"];
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET!;

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig!, endpointSecret);
  } catch (err: any) {
    console.error("⚠️ Webhook signature mismatch", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === "checkout.session.completed") {
    const session: any = event.data.object;

    try {
      const userId = session.metadata.userId;

      // Fetch cart and populate products
      const cart = await Cart.findOne({ userId }).populate("items.productId");
      if (!cart) throw new Error("Cart not found");

      const cartItems = cart.items.map(item => item as any);

      // Map cart items to order items
      const orderItems = cartItems.map(item => {
        const product = item.productId;
        return {
          product: product._id,
          name: product.name,
          price: product.price,
          image: product.images?.[0] || "",
          quantity: item.quantity,
          size: item.size,
          color: item.color,
        };
      });

      const totalAmount = orderItems.reduce(
        (acc, item) => acc + item.price * item.quantity,
        0
      );

      // Create order
      await Order.create({
        user: userId,
        items: orderItems,
        totalAmount,
        paymentStatus: "paid",
        orderStatus: "processing",
      });

      // Clear cart
      cart.items = [];
      await cart.save();

      console.log(`✅ Order created for user ${userId}`);

    } catch (err) {
      console.error("❌ Error creating order from webhook:", err);
    }
  }

  res.status(200).json({ received: true });
};
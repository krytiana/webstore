// src/models/cart.ts
import mongoose, { Document, Types } from "mongoose";

export interface ICartItem {
  productId: Types.ObjectId | any; // populated product
  quantity: number;
  size?: string | null;
  color?: string | null;
}

export interface ICart extends Document {
  userId: Types.ObjectId;
  items: ICartItem[];
}

const cartSchema = new mongoose.Schema<ICart>({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  items: [
    {
      productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product" },
      quantity: { type: Number, default: 1 },
      size: String,
      color: String,
    }
  ]
}, { timestamps: true });

export const Cart = mongoose.model<ICart>("Cart", cartSchema);
import { ObjectId } from "mongodb";
import { db } from "../config/mongo";

const collection = db.collection("addresses");

export interface Address {
  _id?: ObjectId;
  userId: string;
  fullName: string;
  phone: string;
  addressLine: string;
  city: string;
  region: string;
  country: string;
  latitude?: number;
  longitude?: number;
  isDefault?: boolean;
  createdAt?: Date;
}

export const AddressModel = {
  create: async (data: Address) => {
    data.createdAt = new Date();
    data.isDefault = data.isDefault || false;

    const result = await collection.insertOne(data);
    return result;
  },

  findByUser: async (userId: string) => {
    return await collection.find({ userId }).toArray();
  },

  update: async (id: string, userId: string, data: Partial<Address>) => {
    return await collection.updateOne(
      { _id: new ObjectId(id), userId },
      { $set: data }
    );
  },

  delete: async (id: string, userId: string) => {
    return await collection.deleteOne({
      _id: new ObjectId(id),
      userId
    });
  },

  clearDefault: async (userId: string) => {
    return await collection.updateMany(
      { userId },
      { $set: { isDefault: false } }
    );
  },

  setDefault: async (id: string, userId: string) => {
    await collection.updateMany({ userId }, { $set: { isDefault: false } });

    return await collection.updateOne(
      { _id: new ObjectId(id), userId },
      { $set: { isDefault: true } }
    );
  }
};
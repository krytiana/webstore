import express from "express";
import { getUserOrders } from "../controllers/orderController";
import { authenticateToken } from "../middlewares/authMiddleware";

const router = express.Router();

router.get("/orders", authenticateToken, getUserOrders);

export default router;
// src/routes/cartRoutes.ts
import express from "express";
import { addToCart, getCart, removeFromCart, updateCart } from "../controllers/cartController";
import { authenticateToken } from "../middlewares/authMiddleware";

const router = express.Router();

router.post("/add", authenticateToken, addToCart);
router.get("/", authenticateToken, getCart);
router.post("/remove", authenticateToken, removeFromCart);
router.post("/cart/update", authenticateToken, updateCart);

router.get("/cart", (req, res) => {
  res.render("cart");
});


export default router;
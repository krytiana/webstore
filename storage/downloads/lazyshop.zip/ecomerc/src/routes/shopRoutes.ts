//src/routes/shopRoutes.ts
import express from "express";
import { getProducts, getProductDetail } from "../controllers/productController";

const router = express.Router();

router.get("/", getProducts);
router.get("/product/:id", getProductDetail); // <-- use this

export default router;
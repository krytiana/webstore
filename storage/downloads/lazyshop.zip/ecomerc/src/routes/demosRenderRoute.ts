import express from "express";
import { Product } from "../models/Product";

const router = express.Router();

// Animation demo page
router.get("/animation", async (req, res) => {
  const products = await Product.find({});
  res.render("e-commerce/animation", { products });
});

router.get("/shoplite", async (req, res) => {
  const products = await Product.find({});
  res.render("e-commerce/shoplite", { products });
});

export default router;
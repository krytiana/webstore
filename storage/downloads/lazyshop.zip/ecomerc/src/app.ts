// src/app.ts
import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import path from "path";
import dotenv from "dotenv";
import userRoutes from "./routes/userRoutes";
import authRoutes from "./routes/authRoute";
import { refreshToken } from "./middlewares/authMiddleware";
import stripeRoute from "./routes/stripeRoute"
import shopRoutes from "./routes/shopRoutes";
import cartRoutes from "./routes/cartRoutes";
import wishlistRoutes from "./routes/wishlistRoutes";
import recentViewRoutes from "./routes/recentViewRoutes";
import stripeRoutes from "./routes/stripeRoute"
import orderRoutes from "./routes/orderRoutes";
import addressRoutes from "./routes/addressRoutes";
import demosRenderRoute from "./routes/demosRenderRoute"


dotenv.config();

const app = express();

// EJS setup
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "../views"));

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Refresh token endpoint
app.post("/api/refresh-token", refreshToken);

// Routes
app.use("/api/users", userRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/payments", stripeRoute);
app.use("/", shopRoutes);
app.use(cartRoutes);
app.use("/api/cart", cartRoutes);
app.use("/api/wishlist", wishlistRoutes);
app.use("/api/recent", recentViewRoutes);
app.use("/api/stripe", stripeRoutes);
app.use("/api", orderRoutes);
app.use("/api/address", addressRoutes);
app.use("/", demosRenderRoute);

app.get("/dashboard", (req, res) => {
  res.render("dashboard");
});

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date() });
});

// Serve static files if needed (optional)
app.use(express.static(path.join(__dirname, "..", "public")));

app.get("/", (req, res) => {
  res.render("index"); // make sure 'views/index.ejs' exists
});

export default app;
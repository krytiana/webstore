import { getCurrentUser } from "./userService.js";

const API_BASE = "http://localhost:5000/api";
const token = localStorage.getItem("token");

// ------------------ INIT ------------------
async function init() {
  const user = await getCurrentUser();

  if (!user) {
    window.location.href = "/register";
    return;
  }

  document.getElementById("welcomeText").textContent = `Welcome, ${user.name}`;
  document.getElementById("emailText").textContent = user.email;

  
}

// ------------------ TAB SWITCH ------------------
document.querySelectorAll(".sidebar li").forEach(item => {
  item.addEventListener("click", () => {
    const tab = item.dataset.tab;

    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.getElementById(`${tab}Tab`).classList.add("active");
  });
});

// ------------------ CART ------------------
async function loadCart() {
  const res = await fetch(`${API_BASE}/cart`, {
    headers: { Authorization: `Bearer ${token}` }
  });

  const data = await res.json();
  const container = document.getElementById("cartItems");
  container.innerHTML = "";

  if (!data.cart || !data.cart.items.length) {
    container.innerHTML = "<p>Your cart is empty.</p>";
    return;
  }

    container.innerHTML = '<div class="grid"></div>';
    const grid = container.querySelector(".grid");

    data.cart.items.forEach(item => {
      const p = item.productId;

      const div = document.createElement("div");
      div.className = "product-card";

      div.innerHTML = `
        <img src="${p.images?.[0] || ''}">
        <div class="product-info">
          <h4>${p.name}</h4>
          <p>Qty: ${item.quantity}</p>
          <button class="btn remove-btn">Remove</button>
        </div>
      `;

      div.querySelector(".remove-btn").addEventListener("click", async () => {
        await fetch(`${API_BASE}/cart/remove`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({ productId: p._id })
        });

        loadCart();
      });

      grid.appendChild(div);
    });
}

// ------------------ WISHLIST ------------------
async function loadWishlist() {
  const res = await fetch(`${API_BASE}/wishlist`, {
    headers: { Authorization: `Bearer ${token}` }
  });

  const data = await res.json();
  const container = document.getElementById("wishlistItems");
  container.innerHTML = "";

  if (!data.wishlist || !data.wishlist.items || !data.wishlist.items.length) {
    container.innerHTML = "<p>Your wishlist is empty.</p>";
    return;
  }

container.innerHTML = '<div class="grid"></div>';
const grid = container.querySelector(".grid");

data.wishlist.items.forEach(item => {
  const p = item.productId;

  const div = document.createElement("div");
  div.className = "product-card";

  div.innerHTML = `
    <img src="${p.images?.[0] || ''}">
    <div class="product-info">
      <h4>${p.name}</h4>
      <p>$${p.price.toFixed(2)}</p>
      <button class="btn remove-btn">Remove</button>
    </div>
  `;

  div.querySelector(".remove-btn").addEventListener("click", async () => {
    await fetch(`${API_BASE}/wishlist/remove`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ productId: p._id })
    });

    loadWishlist();
  });

  grid.appendChild(div);
});
}

// ------------------ RECENTLY VIEWED ------------------
async function loadRecent() {
  try {
    const res = await fetch(`${API_BASE}/recent`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!res.ok) {
      console.error("Failed to load recent views");
      return;
    }

    const data = await res.json();
    const container = document.getElementById("recentItems");

    // ✅ Empty state
    if (!data.recent || !data.recent.items || data.recent.items.length === 0) {
      container.innerHTML = `
        <div class="card empty-state">
          <h3>No Recent Views</h3>
          <p>Products you view will appear here.</p>
        </div>
      `;
      return;
    }

    // ✅ Render grid
    container.innerHTML = '<div class="grid"></div>';
    const grid = container.querySelector(".grid");

    data.recent.items.forEach(item => {
      const p = item.productId;

      const div = document.createElement("div");
      div.className = "product-card";

      div.innerHTML = `
        <img src="${p.images?.[0] || ''}">
        <div class="product-info">
          <h4>${p.name}</h4>
          <p>$${p.price.toFixed(2)}</p>
        </div>
      `;

      grid.appendChild(div);
    });

  } catch (err) {
    console.error("Recent view error:", err);
  }
}

// ------------------ ORDERS ------------------
async function loadOrders() {
  const res = await fetch(`${API_BASE}/orders`, {
    headers: { Authorization: `Bearer ${token}` }
  });

  if (!res.ok) {
    console.error("Orders API failed:", res.status);
    return;
  }

  const data = await res.json();
  const container = document.getElementById("ordersItems");

  // ✅ Handle empty orders properly
  if (!data.orders || data.orders.length === 0) {
    container.innerHTML = `
      <div class="card">
        <h3>No Orders Yet</h3>
        <p>You haven’t placed any orders yet.</p>
      </div>
    `;
    return;
  }

  // ✅ Render orders if they exist
  container.innerHTML = data.orders.map(order => `
    <div class="card order-card">
      <h4>Order #${order._id.slice(-6)}</h4>
      <p>Total: $${order.totalAmount}</p>
      <p>Status: ${order.orderStatus}</p>
    </div>
  `).join("");
}

// ------------------ LOGOUT ------------------
document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("token");
  window.location.href = "/";
});

// ------------------ LOAD ALL ------------------
document.addEventListener("DOMContentLoaded", () => {
  init();
  loadCart();
  loadWishlist();
  loadOrders();
  loadRecent();
});
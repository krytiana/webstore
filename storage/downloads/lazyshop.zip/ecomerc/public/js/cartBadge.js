//js/cartBadge.js

async function loadCartCount() {
  const token = localStorage.getItem("token");
  if (!token) return;

  const res = await fetch("http://localhost:5000/api/cart", {
    headers: {
      "Authorization": `Bearer ${token}`
    }
  });

  const data = await res.json();

  const totalQty = data.cart?.items?.reduce((sum, i) => sum + i.quantity, 0) || 0;

  const floatingBadge = document.getElementById("floatingCartCount");
  if (floatingBadge) {
    floatingBadge.textContent = totalQty;
    floatingBadge.style.display = totalQty > 0 ? "inline-block" : "none";
  }
}

document.addEventListener("DOMContentLoaded", loadCartCount);
// ===============================
// PRODUCT DETAIL INTERACTIVITY
// ===============================

document.addEventListener("DOMContentLoaded", () => {

  const token = localStorage.getItem("token");
  const productBtn = document.querySelector(".add-to-cart");
  const productId = productBtn?.dataset.id;

  // ===============================
  // RECENT VIEW
  // ===============================
  if (token && productId) {
    fetch("http://localhost:5000/api/recent/add", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ productId })
    }).catch(err => console.error(err));
  }

  // ===============================
  // IMAGE SWITCH
  // ===============================
  const mainImage = document.getElementById("mainProductImage");
  const thumbnails = document.querySelectorAll(".thumbnail");

  thumbnails.forEach(thumb => {
    thumb.addEventListener("click", () => {
      mainImage.src = thumb.src;
      thumbnails.forEach(t => t.classList.remove("active"));
      thumb.classList.add("active");
    });
  });

  // ===============================
  // SIZE & COLOR
  // ===============================
  let selectedSize = null;
  let selectedColor = null;

  document.querySelectorAll(".size-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      selectedSize = btn.textContent;
      document.querySelectorAll(".size-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });

  document.querySelectorAll(".color-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      selectedColor = btn.textContent;
      document.querySelectorAll(".color-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });

  // ===============================
  // QUANTITY
  // ===============================
  let quantity = 1;
  const qtyInput = document.getElementById("quantityInput");

  document.getElementById("increaseQty")?.addEventListener("click", () => {
    quantity++;
    if (qtyInput) qtyInput.value = quantity;
  });

  document.getElementById("decreaseQty")?.addEventListener("click", () => {
    if (quantity > 1) quantity--;
    if (qtyInput) qtyInput.value = quantity;
  });

  // ===============================
  // ADD TO CART
  // ===============================
  productBtn?.addEventListener("click", async () => {
    if (!token) return window.location.href = "/register";

    if (document.querySelector(".size-btn") && !selectedSize) {
      alert("Select size");
      return;
    }

    if (document.querySelector(".color-btn") && !selectedColor) {
      alert("Select color");
      return;
    }

    const res = await fetch("http://localhost:5000/api/cart/add", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({
        productId,
        quantity,
        size: selectedSize,
        color: selectedColor
      })
    });

    const data = await res.json();
    if (data.success) {
      alert("Added to cart ✅");
      loadCartCount();
    }
  });

  // ===============================
  // WISHLIST
  // ===============================
  document.querySelector(".wishlist")?.addEventListener("click", async (e) => {
    if (!token) return window.location.href = "/register";

    const btn = e.target;

    const res = await fetch("http://localhost:5000/api/wishlist/add", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ productId, size: selectedSize, color: selectedColor })
    });

    const data = await res.json();
    if (data.success) {
      btn.textContent = "❤️ Added";
      btn.disabled = true;
    }
  });

});